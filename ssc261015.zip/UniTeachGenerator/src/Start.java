import uniteach.test.Database;


public class Start {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Hello world");
		Database db = new Database();
		db.create();

	}

}
