package uniteach.resources;

public enum Role {
	LECTURER, STUDENT
}
