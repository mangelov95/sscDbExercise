package uniteach.resources;

public enum Title {
	MR,MS,MRS,MISS
}
