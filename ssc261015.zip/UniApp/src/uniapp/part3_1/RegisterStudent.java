package uniapp.part3_1;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import uniteach.test.Database;

public class RegisterStudent {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String title, forename, familyName;
		String[] titles = {"MR", "MS", "MRS", "CAPT", "DOC"};
		ArrayList<String> validTitles = new ArrayList<String>();
		validTitles.add("MR");
		validTitles.add("MS");
		validTitles.add("MRS");
		validTitles.add("CAPT");
		validTitles.add("DOC");
		
		title = "";
		forename = "";
		familyName = "";
		while (!validTitles.contains(title.toUpperCase())) {
			System.out.println("Please enter the title, first name and family name of the student: ");
			title = input.next();
			forename = input.next();
			familyName = input.next();
			if (!validTitles.contains(title.toUpperCase())) {
				System.out.println("Sorry, the title isn't in the right format. It should be one of the following: " +
								   "MR,MS,MRS,CAPT,DOC");
			}
		}
		System.out.print("Name: " + title + " " + forename + " " + " " + familyName);
		System.out.println();
	}

}
